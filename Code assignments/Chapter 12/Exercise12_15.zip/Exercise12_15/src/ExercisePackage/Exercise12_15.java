package ExercisePackage;
import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Arrays;
/**
 * <h1> Exercise 12_15 </h1>
 * <p>Working with files and I/O. displaying numbers on a file then bringing them back into the code. </p>
 * <p> Date created Jan. 12 2022 </p>
 * @author Elise C Sarles
 *
 */
public class Exercise12_15 {
	public static void main(String[] args) throws 
	 FileNotFoundException {
		Scanner input = new Scanner(System.in);
		File fx = new File("Exercise12_15.txt");
		if(fx.exists() ) {
			System.out.println("The file " + fx.getName() + " already exists. Do you want to override it?");
			String answer = input.nextLine();
			String yes = "yes";
			String no = "no";
			
			if (isEqual(answer, yes)) {
				continueProgram(fx);
			}
			else if ( isEqual(answer, no)) {
				System.out.print("Exited Program.");
				System.exit(0);
			}
		}

		
	}	
	/**
	 * The method Holds the actions of the code if yes is giving in the first method.
	 * @param fx (file; it connects to an actual file that will be changed.
	 * @throws FileNotFoundException
	 */
	public static void continueProgram(File fx)  throws 
	 FileNotFoundException{
		Scanner input = new Scanner(fx);
		int count = 100;
		int number = 1;
		String page = " ";
		int[] numbers = new int[count];
		java.io.PrintWriter output = new java.io.PrintWriter(fx);
		System.out.println(fx.exists());
		System.out.println( "The file name is " + fx.getName());
		System.out.println("Can it be written in " + fx.canWrite());
		if (fx.canWrite()) {
			for(int i = 0; i < count; i ++) {
				output.print((int)(Math.random() * 10) + " ");
			}
			output.close();
		}
		else if (!fx.canWrite()) {
			System.out.print("Unable to continue.");
			System.exit(0);
		}
		System.out.println("On the file " + fx.getName() + " is ");
		int k = 0;
		while (input.hasNext()) {
			number = input.nextInt();
			page += (number + " ");
			numbers[k] = number;
			k++;
			
		}
		System.out.println(page);
		input.close();
		
		System.out.println("The numbers sorted in increasing order: ");
		Arrays.sort(numbers);
		
		for (int i = 0; i < count; i++){
			System.out.print(numbers[i] + " ");
		}
		
		
	}
	/**
	 * This method is use to compare strings.
	 * <pre>Examples: {@code returnType(Yes, no) returns false returnType(YES, yes) returns true} </pre>
	 * @param m (String; String user has entered. checking to see if it is the same as n)
	 * @param n (String; string has set value not user based that m is being compared to.)
	 * @return true or false (depending on it m and n are the same thing)
	 */
	public static boolean isEqual(String m, String n){
		if (m.length() != n.length()){
			return false;
		}
		for(int i = 0; i < m.length(); i++){
			if (Character.toUpperCase(m.charAt(i)) != Character.toUpperCase(n.charAt(i))){
				return false;
			}
		}
		return true;
	}
}
