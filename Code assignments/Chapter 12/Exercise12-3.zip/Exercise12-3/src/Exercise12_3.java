import java.util.Scanner;
/**
 * <h1>Exercise 12_3 </h1>
 * <p> Out of bounds try and catch</p>
 *
 *<p>Created Jan. 10 2022 </p>
 *
 * @author Elise Sarles
 */
public class Exercise12_3 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean continueinput = true;
		String bolds = "Out of Bounds";
		
		
		int [] x = new int [100];
		for (int i = 0; i < x.length; i++){
			x[i] = (int)(Math.random()*10);
		}
		do{
			try{
				System.out.println("Please enter an index number of the array. 0-100 ");
				int y = input.nextInt();
				System.out.println("The Array value is " + x[y]);
				continueinput = false;
				
			}
			catch(java.lang.ArrayIndexOutOfBoundsException e){
				System.out.println("Try again. Number was " + bolds);
				
				
			}
		} while (continueinput);
	/*
		for (int i = 0; i < x.length; i++){
			System.out.print(x[i] + " ");
		}
	*/
	}
	 

}
